var preguntas = [
	{
		"pregunta": "¿Cuál de estos equipos te agrada más?",
		"respuestas":[
			{
				"texto": "Porto, porque hay muchos mexicanos",
				"valor": 3
			},
			{
				"texto": "Benfica, ahí está Raulito",
				"valor": 0
			},
			{
				"texto": "Albacete, de ahí salió Iniesta",
				"valor": 2
			},
			{
				"texto": "Deportivo La Coruña, soy medio hipster",
				"valor": 1
			}
		]
	},
	{
		"pregunta": "¿En qué posición te gustaría jugar?",
		"respuestas":[
			{
				"texto": "Contención, para tronar huesos",
				"valor": 1
			},
			{
				"texto": "Defensa central, soy elegante y aguerrido",
				"valor": 0
			},
			{
				"texto": "Portero, soy tan ágil como un gato",
				"valor": 2
			},
			{
				"texto": "Medio creativo, soy muy inteligente",
				"valor": 3
			}
		]
	},
	{
		"pregunta": "¿Quién de estos cracks sería un ídolo para ti?",
		"respuestas":[
			{
				"texto": "Carlos Valderrama, por su melena",
				"valor": 0
			},
			{
				"texto": "Cristiano Ronaldo, porque siiiiiuuuuuu",
				"valor": 3
			},
			{
				"texto": "Gianluigi Buffon, porque es imbatible",
				"valor": 2
			},
			{
				"texto": "Rafael Márquez, Kaizser de Zamora forever",
				"valor": 1
			}
		]
	},
	{
		"pregunta": "¿Qué prefieres hacer una tarde de sábado?",
		"respuestas":[
			{
				"texto": "Rezar, primero está Dios",
				"valor": 0
			},
			{
				"texto": "Jugar videojuegos para sacar el estrés",
				"valor": 3
			},
			{
				"texto": "Jugar al trompo, soy un crack",
				"valor": 2
			},
			{
				"texto": "Ver lucha libre",
				"valor": 1
			}
		]
	},
	{
		"pregunta": "¿Qué música prefieres?",
		"respuestas":[
			{
				"texto": "Salsa, sabor tropical",
				"valor": 2
			},
			{
				"texto": "Banda, ajúaaaa",
				"valor": 1
			},
			{
				"texto": "Cumbia para el bailongo",
				"valor": 3
			},
			{
				"texto": "Rock and roll, baby",
				"valor": 0
			}
		]
	},
	{
		"pregunta": "¿Qué look te va mejor?",
		"respuestas":[
			{
				"texto": "Bien peinado para las chiquibabies",
				"valor": 3
			},
			{
				"texto": "¿Peinarse? ¿Qué es eso?",
				"valor": 0
			},
			{
				"texto": "Ya me salieron entradotas, no tengo mucha elección",
				"valor": 1
			},
			{
				"texto": "Soy formal, cero payasadas",
				"valor": 2
			}
		]
	}
];

var resultados = [
	"Eres religioso como Ned Flanders, pero eso no te quita lo extravagante y rockero. Lo tuyo es la defensa, sitio en el que no tienes miedo a nada ni nadie.",
	"Naciste para ser capitán del Tri. Eres plurifuncional, pero te gusta la acción en el medio campo. No le sacas a los golpes y por eso te encantan los deportes de contacto.",
	"KLo tuyo es la sobriedad y por eso tu posición ideal es la portería. Lo más importante es hacer bien tu trabajo.",
	"Como el crack colombiano, te gustaría pasar por el Porto y ser el cerebro de tu equipo. No le haces el feo a bailar una buena cumbia y eres el as de los videojuegos."
]; 